SFG USA - YWAM GO28 Delivery Guide

Extract all files, then open index.html in a browser.
Includes the interactive HTML guide and printable run sheet/timeline PDF.

Site: https://sfg-usa-go28-delivery-guide.adrian-sfg-md.chatgpt.site
Saved site version: 1
Source commit: 1973a7f95d0d2d746b0ac18e0f560c4392f4eaab
Working baseline: 28 October 2026
Packaged: 30 October 2026

Planner is the delivery record. Browser review ticks do not update Planner.
The hosted site is private; the extracted files can be opened locally.
This is the SFG delivery-guide site, not the GO28 public/client-facing website.
